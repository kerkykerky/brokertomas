package com.example.broker.messageBroker;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

@Component
public class MessageBroker {

    private boolean mock = true;
    private final String q1 = "GPP-to-broker-queue";
    private final String q2 = "broker-to-SAA-queue";
    private final String q3 = "SAA-to-broker";
    private final String q4 = "broker-response-from-SAA-to-GPP";

    @Autowired
    JmsTemplate jmsTemplate;

    @JmsListener(destination = q1)
    public void gppListener(String message) {
        if (!mock) {
            System.out.println("Received message from GPP from queue " + q1 + " body of message : " + message + "MOCK" + mock);
            jmsTemplate.convertAndSend(q2, "Message from broker to queue " + q2 + " body of message: " + message);
            System.out.println("Message sent to " + q2 + " for SAA");
        } else {
            System.out.println("Received message from GPP from queue " + q1 + " body of message : " + message + "MOCK" + mock);
            jmsTemplate.convertAndSend(q4, "MOCK from broker to queue " + q4 + " body of message: " + message);
            System.out.println("Message sent to " + q4 + " for GPP MOCK");
        }
    }

    @JmsListener(destination = q3)
    public void saaResponseListener(String message) {
        System.out.println("Received response from SAA from queue " + q3 + " body of message : " + message);
        jmsTemplate.convertAndSend(q4, message);
        System.out.println("Response sent to " + q4 + " for GPP");
    }
}
