package com.example.listener.listener;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;


@Component
public class Listener {

    private final String q1 = "broker-to-SAA-queue";
    private final String q2 = "SAA-to-broker";


    @Autowired
    JmsTemplate jmsTemplate;

    @JmsListener(destination = q1)
    public void listener(String message) {
        System.out.println("Received Message from broker from queue: " + q1 + " body of message: " + message);
        jmsTemplate.convertAndSend(q2,"SAA successfully received your message");
        System.out.println("Response sent to " + q2);
    }
}
