package com.example.listener;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ListenerApplicationTests {

    @Test
    void contextLoads() {
    }

}
