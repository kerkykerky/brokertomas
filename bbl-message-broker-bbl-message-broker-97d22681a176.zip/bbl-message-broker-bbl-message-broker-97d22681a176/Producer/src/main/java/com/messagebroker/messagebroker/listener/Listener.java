package com.messagebroker.messagebroker.listener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import javax.jms.JMSException;
import javax.jms.TextMessage;

@Component
public class Listener {

    private final String q1 = "broker-response-from-SAA-to-GPP";
    private static final Logger logger = LoggerFactory.getLogger(Listener.class);

    @JmsListener(destination = q1)
    public void saaListenerFromBroker(TextMessage message) throws JMSException {
        logger.info("JMS listener received text message: {}", message.getText());
    }

}
