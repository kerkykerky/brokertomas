package com.messagebroker.messagebroker.sender;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/produce")
public class Sender {

    private final String q1 = "GPP-to-broker-queue";

    @Autowired
    JmsTemplate jmsTemplate;

    @PostMapping("{name}")
    public String sendName(@PathVariable("name") final String message) {
        jmsTemplate.convertAndSend(q1, message);
        System.out.println("Message successfully sent to queue: " + q1 + " body of message: " + message);
        return "Published Successfully";
    }
}
