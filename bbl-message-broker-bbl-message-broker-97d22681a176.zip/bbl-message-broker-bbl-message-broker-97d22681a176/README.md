# Broker #


### Ako to funguje ###

Treba mať spustený ActiveMQ máme tri Spring Appky
* Producer (GPP)
* Consumer (SAA)
* Broker 

Všetko chodí na jeden ActiveMQ server ale do rôznych Queue.
Mock je nastavený v broker ako boolean hodnota.  
Ak je true tak tak broker posiela hned do queue na ktory ma GPP listener.

Ak je False tak sa odošle na queue kde ma broker listener ten ho spracuje  
odosle na queue kde ma listener SAA, ten ho spracuje odošle response  
na queue kde ma broker listener ten ho odošle na dalšie queue kde ma  
listener GPP.