package com.messagebroker.messagebroker;

import com.messagebroker.messagebroker.consumer.component.MessageListener;
import com.messagebroker.messagebroker.producer.controller.MessageSender;
import org.apache.activemq.junit.EmbeddedActiveMQBroker;
import org.junit.ClassRule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import javax.jms.JMSException;
import javax.jms.TextMessage;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = { TestConfiguration.class, MessageSender.class })
public class EmbeddedActiveMqTests4 {

    @Autowired
    private MessageSender messageSender;

    @SpyBean
    private MessageListener messageListener;

    @ClassRule
    public static EmbeddedActiveMQBroker embeddedBroker = new EmbeddedActiveMQBroker();

    @Test
    public void whenSendingMessage_thenCorrectQueueAndMessageText() throws JMSException {
        String queueName = "queue-2";
        String messageText = "Test message";

        messageSender.sendTextMessage(queueName, messageText);

        assertEquals(1, embeddedBroker.getMessageCount(queueName));
        TextMessage sentMessage = embeddedBroker.peekTextMessage(queueName);
        try {
            assertEquals(messageText, sentMessage.getText());
        } catch (JMSException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void whenListening_thenReceivingCorrectMessage() throws JMSException {
        String queueName = "queue-1";
        String messageText = "Test message";

        embeddedBroker.pushMessage(queueName, messageText);
        assertEquals(1, embeddedBroker.getMessageCount(queueName));

        ArgumentCaptor<TextMessage> messageCaptor = ArgumentCaptor.forClass(TextMessage.class);

        Mockito.verify(messageListener, Mockito.timeout(100)).sampleJmsListenerMethod(messageCaptor.capture());

        TextMessage receivedMessage = messageCaptor.getValue();
        assertEquals(messageText, receivedMessage.getText());
    }
}
