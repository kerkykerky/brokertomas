package com.messagebroker.messagebroker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MessagebrokerApplication {

    public static void main(String[] args) {
        SpringApplication.run(MessagebrokerApplication.class, args);
    }

}
